function MyInfoPage() {
  return (
    <div className="flex-1 bg-white rounded-[20px] flex items-center justify-center">
      <p className="text-[18px] font-medium text-dark" style={{ letterSpacing: '-0.36px' }}>
        My Info — Coming Soon
      </p>
    </div>
  )
}

export default MyInfoPage
