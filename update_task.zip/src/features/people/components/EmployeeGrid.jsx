import EmployeeCard from './EmployeeCard'

function EmployeeGrid({ employees }) {
  return (
    <div className="grid grid-cols-4 gap-6">
      {employees.map((employee) => (
        <EmployeeCard
          key={employee.id}
          name={employee.name}
          role={employee.role}
          avatar={employee.avatar}
        />
      ))}
    </div>
  )
}

export default EmployeeGrid
