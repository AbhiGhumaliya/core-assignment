import MaskIcon from '../../../shared/components/MaskIcon'

function SearchAndActions() {
  return (
    <div className="flex items-center justify-between gap-4 shrink-0">
      {/* Search bar */}
      <div className="flex items-center gap-3 border border-divider rounded-full px-4 py-[10px] flex-1 max-w-[460px]">
        <img src="/assets/icons/search.svg" alt="" className="w-4 h-4 shrink-0" />
        <span
          className="text-[14px] font-normal"
          style={{ letterSpacing: '-0.28px', color: 'rgba(61, 57, 54, 0.60)' }}
        >
          Search by Employee Name or Number
        </span>
      </div>

      {/* Action buttons */}
      <div className="flex items-center gap-4 shrink-0">
        {/* Download + Filter */}
        <div className="flex items-center gap-2">
          <button className="flex items-center justify-center p-[10px] rounded-xl border-[1.5px] border-dark">
            <MaskIcon src="/assets/icons/download.svg" color="#3d3936" size={24} />
          </button>
          <button className="flex items-center justify-center p-[10px] rounded-xl border-[1.5px] border-dark">
            <MaskIcon src="/assets/icons/filter.svg" color="#3d3936" size={20} />
          </button>
        </div>

        {/* Add button — dark rounded square with white + icon */}
        <button
          className="w-12 h-12 flex items-center justify-center rounded-[14px] shrink-0 cursor-pointer"
          style={{ backgroundColor: '#3d3936' }}
        >
          <MaskIcon src="/assets/icons/add.svg" color="#ffffff" size={16} />
        </button>

        {/* View toggle — SVG is self-contained with border; no extra CSS border needed */}
        <img
          src="/assets/icons/view-toggle.svg"
          alt="View options"
          className="h-12 w-auto cursor-pointer"
        />
      </div>
    </div>
  )
}

export default SearchAndActions
